#!/bin/bash

kubeadm token create --print-join-command